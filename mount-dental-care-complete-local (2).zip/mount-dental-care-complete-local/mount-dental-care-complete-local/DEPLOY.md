# Deploying Mount Dental Care

The whole site ships as **one service**: Django serves the API, Django Admin,
the uploaded media and the built React app (see `backend/config/urls.py`), so
there is no separate frontend host and no CORS configuration to maintain.

```
repository/
  backend/     Django + DRF + Admin  (build.sh, release.sh, Procfile, .env.example)
  frontend/    React + Vite          (built into frontend/dist during the build)
  render.yaml  Render Blueprint: web service + Postgres + persistent media disk
```

---

## 1. Push the code to GitHub

Render (and every other platform below) deploys from a Git repository.

```bash
git init
git add .
git commit -m "Mount Dental Care website"
git branch -M main
git remote add origin https://github.com/<you>/mount-dental-care.git
git push -u origin main
```

`.gitignore` already keeps `db.sqlite3`, `backend/media`, `frontend/dist`,
`node_modules` and `staticfiles` out of the repository — the platform builds
those itself.

## 2. Create the services (Render Blueprint)

1. Open the Render dashboard → **New +** → **Blueprint**.
2. Pick the repository. Render reads `render.yaml` and creates:
   * **mount-dental-db** — managed PostgreSQL,
   * **mount-dental-care** — the web service (Python, root dir `backend`),
   * a **1 GB disk** mounted at `/var/mount-dental-media` for uploaded images.
3. Render asks for the values marked `sync: false`:

   | Variable | What to enter |
   |---|---|
   | `DJANGO_SUPERUSER_USERNAME` | the username you want for `/admin/` |
   | `DJANGO_SUPERUSER_EMAIL` | clinic email |
   | `DJANGO_SUPERUSER_PASSWORD` | a strong password for `/admin/` |
   | `EMAIL_HOST_USER` | the Gmail address that sends the OTP codes |
   | `EMAIL_HOST_PASSWORD` | 16-character **Google app password** for that address |
   | `DEFAULT_FROM_EMAIL` | same Gmail address |

4. **Apply**. The first build installs the Python packages, builds the React
   app, collects the static files, then the release step runs
   `migrate` → `seed_demo` → `ensure_admin`.

## 3. What runs on every deploy

| Step | Command | Notes |
|---|---|---|
| Build | `backend/build.sh` | pip install, `npm ci && npm run build`, `collectstatic` |
| Release | `backend/release.sh` | `migrate`, `seed_demo`, `ensure_admin` |
| Start | `gunicorn config.wsgi:application` | serves API, Admin, `/static/`, `/media/`, React |

`seed_demo` is safe to re-run: it creates missing records and only fills blank
fields, so everything edited in Django Admin is preserved. `SEED_RESET=true`
forces the bundled defaults over existing records (use it once, on purpose).

`ensure_admin` creates the admin login on the first deploy and only repairs
staff/superuser flags after that. Set `ADMIN_RESET_PASSWORD=true` for one
deploy to force a new password, then set it back to `false`.

## 4. Verify the deployment

| Check | Expected |
|---|---|
| `https://<app>.onrender.com/` | the website loads with the seeded content |
| `https://<app>.onrender.com/api/site/` | JSON with `site`, `services`, `doctors`, `gallery`, `awards`... filled |
| `https://<app>.onrender.com/admin/` | Django Admin login works with the superuser above |
| Admin → Site Settings → change the Hero title, save, reload the site | the new title appears |
| Admin → Doctors → add a doctor with a photo, save, reload | the new doctor appears with the image |
| Admin → Doctors → delete it again | the section still renders (React falls back gracefully) |
| Admin → Hero Banners → upload an image | it appears in the hero carousel |
| Booking form → email OTP | the code arrives (see note on SMTP below) |

Uploaded images are stored on the persistent disk. If a photo is uploaded and
disappears after a redeploy, `MEDIA_ROOT_DIR` is not pointing at the disk.

## 5. Custom domain

Render → the service → **Settings → Custom Domains** → add the domain, then
update these variables:

```
ALLOWED_HOSTS           = mountdentalcare.com,www.mountdentalcare.com
CSRF_TRUSTED_ORIGINS    = https://mountdentalcare.com,https://www.mountdentalcare.com
```

Also set `SECURE_SSL_REDIRECT=true` and (later) `SECURE_HSTS_SECONDS=31536000`.

## 6. Email (appointment OTP)

The booking flow emails a 4-digit code through Gmail SMTP:

```
EMAIL_BACKEND          = django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST             = smtp.gmail.com
EMAIL_PORT             = 587
EMAIL_USE_TLS          = True
EMAIL_HOST_USER        = your-clinic@gmail.com
EMAIL_HOST_PASSWORD    = <16-character Google app password>
DEFAULT_FROM_EMAIL     = your-clinic@gmail.com
```

* The Gmail account needs 2-step verification before an **app password** can be
  created (Google account → Security → App passwords).
* Test it from the host shell: `python manage.py test_gmail you@example.com`.
* Some platforms block outbound SMTP. If Gmail cannot be reached from the host,
  switch to an email API (Resend, Brevo, SendGrid, Mailgun...) using a small
  custom email backend — the OTP flow itself does not change.

## 7. Other hosts

`backend/build.sh`, `backend/release.sh` and `backend/Procfile` are generic, so
the same repository deploys to:

* **Railway** — new project from the repo, root directory `backend`, add a
  Postgres plugin (it sets `DATABASE_URL`), add a volume mounted at
  `/var/mount-dental-media` and set `MEDIA_ROOT_DIR` to it.
* **Heroku** — `heroku buildpacks:set heroku/python`, `heroku pg:create`,
  the `Procfile` provides `web` and `release`.
* **DigitalOcean App Platform** — app from the repo, component type *Web
  Service*, HTTP port from `$PORT`, attach a shared volume for media.
* **Any VPS** — install Python 3.12 + Node 22, run `./build.sh`,
  `./release.sh`, then `gunicorn config.wsgi:application` behind nginx, with
  `MEDIA_ROOT_DIR` and `STATIC_ROOT` on disk.

Required environment variables on every host:

```
SECRET_KEY              long random string
DEBUG                   false
ALLOWED_HOSTS           the deployed domain
CSRF_TRUSTED_ORIGINS    https://the-deployed-domain
DATABASE_URL            the Postgres connection string
MEDIA_ROOT_DIR          the mounted persistent disk
DJANGO_SUPERUSER_*      admin login for the first deploy
EMAIL_HOST_*            Gmail account + app password
```

## 8. Day-to-day commands

```bash
python manage.py migrate            # apply schema changes
python manage.py seed_demo          # publish/refresh the bundled content
python manage.py seed_demo --reset  # let the bundle overwrite existing rows
python manage.py ensure_admin       # create/repair the admin login
python manage.py collectstatic      # after adding static files
python manage.py test clinic        # admin + content checks (see below)
```

## 9. Automated checks

`python manage.py test clinic` runs the suite that backs the "everything can be
managed from Admin" claim:

* **`test_admin_crud`** — for every model registered in Django Admin it opens
  the real Add screen, saves a record, edits it through the Change screen and
  deletes it through the Delete screen, asserting after each step that the
  public API still answers. Models are discovered from `admin.site._registry`,
  so a model registered later is covered automatically.
* **`test_seed_and_api`** — after `seed_demo`, every section of the page has
  content, the media files exist, image URLs carry their cache-busting token,
  re-running the seed creates no duplicates, and the API payload keeps the
  exact keys `frontend/src/App.jsx` reads.
